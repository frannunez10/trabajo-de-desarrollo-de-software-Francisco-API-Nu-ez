package com.example.apirest.services;

import com.example.apirest.entities.Autor;
import com.example.apirest.entities.Base;

public interface AutorService extends BaseService<Autor, Long> {
}
